<?php
namespace app\forms;

use std, gui, framework, app;


class chatInfo extends AbstractForm
{

    /**
     * @event Close.action 
     */
    function doCloseAction(UXEvent $e = null)
    {
        $this->hide();
    }


    /**
     * @event Minimize.action 
     */
    function doMinimizeAction(UXEvent $e = null)
    {
        app()->minimizeForm('MainForm');
    }

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        global $chat_id;
        $chat_info=nextModule::query('messages.getChat', ['chat_id'=>$chat_id]);
            Element::loadContentAsync($this->chat_image, $chat_info['response']['photo'], function () use ($chat_image, $this) {
        });
        $users=explode(',',$chat_info['response']['users']);
        $this->chat_count_label->text= count($users).' members';
        $this->chat_title_label->text=$chat_info['response']['title'];
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        app()->showForm(inviteChat);
    }
    
    function addUser()
    {
        $a = nextModule::query('messages.getChats');
        foreach ($a['response']['items'] as $dialog)
        {
            $main = new UXHBox;
            $main->style = "-fx-padding: 5px;";
            $photo = new UXImageView;
            $photo->size = [50,50];
            Element::loadContentAsync($photo, $dialog['photo'], function () use ($this, $photo) {
                $this->setBorderRadius($photo, 255);
            });
            $body = new UXVBox;
            $body->paddingLeft = 5;
            $name = new UXLabel($dialog['title']);
            $name->font->bold = true;
            $name->textColor = '#FFFFFF';
            $message = new UXLabel(urldecode($dialog['last_message']['message']));
            $message->id=$dialog['chat_id'].'chat_d';
            $message->textColor = '#707378';
            $main->add($photo);
            $main->id=$dialog['chat_id'].'_chat';
            $body->add($name);
            $body->add($message);
            $main->add($body);
            $main->on('click', function () use ($dialog) {

            });
            self::FadeIn($main, 'RIGHT');
            $this->listView->items->add($main);
        }  
        $this->Dialogs->contextMenu = new UXContextMenu; 
        
        $invite_user = new UXMenuItem('Delete user from chat'); 
        $invite_user->on('action', function(){ 
            global $invite_chat_id;
            $data = $this->Dialogs->selectedItem->id; 
            $invite_chat_id=str_replace('_chat', '', $data);
           // pre($data);
           $chat_info=nextModule::query('messages.getChat', ['chat_id'=>$invite_chat_id]);
            $this->invite_label->text='Invite user to chat '.$chat_info['response']['title'];
            $this->invite_pannel->toFront();
                //app()->form('MainForm')->$data->text='*Message deleted*';
                
        });
             
        $this->Dialogs->contextMenu->items->add($invite_user);
    }

}
