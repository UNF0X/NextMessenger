<?php
namespace app\modules;

use std, gui, framework, app;


class tray extends AbstractModule
{

    /**
     * @event timer.action 
     */
    function doTimerAction(ScriptEvent $e = null)
    {    
        //var_dump('timer');
        global $sec;
        $sec++;
        if($sec>5){$sec=0;}
    }

}
